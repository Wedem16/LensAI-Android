# LensAI — Free Android Starter

A new, open-source Android camera starter project. This is **not** the recovered original LensAI 1.4.7 source; it is a clean rebuild starter.

## Current features
- Opens the device camera using Android's camera app.
- Lets the user capture a photo and preview the result.
- No account, subscription, ads, or paid AI API is required.
- GitHub Actions builds a debug APK and uploads it as a workflow artifact.

## Build from a phone using GitHub
1. Create a **public** repository on GitHub named `LensAI-Android`.
2. Upload all files and folders from this ZIP, preserving their paths.
3. Open the repository's **Actions** tab.
4. If prompted, enable GitHub Actions.
5. Open the workflow named **Build LensAI APK**, then tap **Run workflow** (or push a commit to trigger it).
6. Open the completed run and download the `LensAI-debug-apk` artifact.
7. Extract the artifact ZIP to get `app-debug.apk`.

## Important
- This starter does not include advanced AI zoom, enhancement, or object recognition yet.
- The APK is a debug build, suitable for testing. A release APK should be signed securely before broad distribution.
- Make sure any code/assets you add are yours or properly licensed.
