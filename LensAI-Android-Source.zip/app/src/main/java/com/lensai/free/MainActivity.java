package com.lensai.free;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;

public class MainActivity extends Activity {
    private static final int REQUEST_CAMERA = 101;
    private static final int REQUEST_GALLERY = 102;
    private ImageView preview;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(24), dp(20), dp(20));
        page.setBackgroundColor(0xFF101116);

        TextView title = new TextView(this);
        title.setText("LensAI");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(32);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView subtitle = new TextView(this);
        subtitle.setText("FREE CAMERA • No subscription");
        subtitle.setTextColor(0xFFB8C0D0);
        subtitle.setTextSize(13);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle, new LinearLayout.LayoutParams(-1, dp(32)));

        preview = new ImageView(this);
        preview.setBackgroundColor(0xFF20232B);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, 0, 1);
        imageParams.setMargins(0, dp(16), 0, dp(16));
        page.addView(preview, imageParams);

        status = new TextView(this);
        status.setText("Capture a photo or choose one from your gallery.");
        status.setTextColor(0xFFE0E4EC);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        page.addView(status, new LinearLayout.LayoutParams(-1, dp(48)));

        Button capture = makeButton("Open Camera");
        capture.setOnClickListener(v -> openCamera());
        page.addView(capture, buttonParams());

        Button gallery = makeButton("Choose from Gallery");
        gallery.setOnClickListener(v -> openGallery());
        page.addView(gallery, buttonParams());

        TextView footer = new TextView(this);
        footer.setText("Free to use. Photos stay on your device unless you share them.");
        footer.setTextColor(0xFF8D96A8);
        footer.setTextSize(12);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(12), 0, 0);
        page.addView(footer, new LinearLayout.LayoutParams(-1, dp(42)));

        setContentView(page);
    }

    private Button makeButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        return button;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
        p.setMargins(0, dp(5), 0, dp(5));
        return p;
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, REQUEST_CAMERA);
        } else {
            Toast.makeText(this, "No camera app found on this device.", Toast.LENGTH_LONG).show();
        }
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Choose a photo"), REQUEST_GALLERY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;

        try {
            Bitmap bitmap = null;
            if (requestCode == REQUEST_CAMERA) {
                Object extra = data.getExtras() == null ? null : data.getExtras().get("data");
                if (extra instanceof Bitmap) bitmap = (Bitmap) extra;
            } else if (requestCode == REQUEST_GALLERY) {
                Uri uri = data.getData();
                if (uri != null) {
                    try (InputStream input = getContentResolver().openInputStream(uri)) {
                        bitmap = BitmapFactory.decodeStream(input);
                    }
                }
            }

            if (bitmap != null) {
                preview.setImageBitmap(bitmap);
                status.setText("Photo loaded. You can capture another or choose a different image.");
            } else {
                status.setText("The image could not be loaded. Try another photo.");
            }
        } catch (Exception e) {
            status.setText("Could not open the selected image.");
        }
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
